create function raster_eq(raster, raster) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.raster_hash($1) = public.raster_hash($2)
$$;
