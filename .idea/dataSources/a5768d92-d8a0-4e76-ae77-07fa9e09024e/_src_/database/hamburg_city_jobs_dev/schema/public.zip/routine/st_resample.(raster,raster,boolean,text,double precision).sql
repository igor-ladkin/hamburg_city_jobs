create function st_resample(rast raster, ref raster, usescale boolean, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125) returns raster
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.st_resample($1, $2, $4, $5, $3)
$$;
