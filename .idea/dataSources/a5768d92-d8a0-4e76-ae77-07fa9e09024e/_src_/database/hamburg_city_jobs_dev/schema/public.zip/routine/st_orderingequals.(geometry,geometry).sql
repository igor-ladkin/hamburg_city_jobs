create function st_orderingequals(geometrya geometry, geometryb geometry) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT $1 OPERATOR(public.~=) $2 AND public._ST_OrderingEquals($1, $2)

$$;
