create function st_covers(text, text) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ST_Covers($1::public.geometry, $2::public.geometry);
$$;
