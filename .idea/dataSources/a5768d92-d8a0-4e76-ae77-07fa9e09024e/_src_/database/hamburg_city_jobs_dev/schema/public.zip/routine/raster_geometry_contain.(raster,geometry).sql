create function raster_geometry_contain(raster, geometry) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
select $1::geometry ~ $2
$$;
