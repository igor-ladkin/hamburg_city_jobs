create function raster_contained_by_geometry(raster, geometry) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
select $1::geometry OPERATOR(public.@) $2
$$;
