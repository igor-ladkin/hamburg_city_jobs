create function st_curvetoline(geometry, integer) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ST_CurveToLine($1, $2::float8, 0, 0)
$$;
