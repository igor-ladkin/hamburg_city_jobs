create function st_setvalues(rast raster, nband integer, x integer, y integer, newvalueset double precision[], nosetvalue double precision, keepnodata boolean DEFAULT false) returns raster
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._ST_setvalues($1, $2, $3, $4, $5, NULL, TRUE, $6, $7)
$$;
