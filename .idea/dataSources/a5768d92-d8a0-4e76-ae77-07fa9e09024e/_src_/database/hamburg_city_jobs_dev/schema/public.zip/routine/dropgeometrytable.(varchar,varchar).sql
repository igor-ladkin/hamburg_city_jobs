create function dropgeometrytable(schema_name character varying, table_name character varying) returns text
LANGUAGE SQL
AS $$
SELECT public.DropGeometryTable('',$1,$2)
$$;
