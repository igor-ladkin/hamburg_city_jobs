create function st_snaptogrid(rast raster, gridx double precision, gridy double precision, scalexy double precision, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125) returns raster
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._ST_gdalwarp($1, $5, $6, NULL, $4, $4, $2, $3)
$$;
