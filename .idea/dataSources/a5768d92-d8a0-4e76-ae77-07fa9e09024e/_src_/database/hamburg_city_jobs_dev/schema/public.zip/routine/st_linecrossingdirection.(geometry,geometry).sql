create function st_linecrossingdirection(geom1 geometry, geom2 geometry) returns integer
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT CASE WHEN NOT $1 OPERATOR(public.&&) $2 THEN 0 ELSE public._ST_LineCrossingDirection($1,$2) END
$$;
