create function st_rastertoworldcoordy(rast raster, xr integer, yr integer) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT latitude FROM public._ST_rastertoworldcoord($1, $2, $3)
$$;
